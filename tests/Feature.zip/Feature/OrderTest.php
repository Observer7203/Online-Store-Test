<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Product;
use App\Models\User;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Cart;
use App\Models\CartItem;
use Illuminate\Foundation\Testing\RefreshDatabase;

class OrderTest extends TestCase
{
    use RefreshDatabase;

        protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }



    public function test_guest_can_create_order()
    {
        $product = Product::firstOrFail();

        // Гость кладет товар в корзину
        $this->postJson('/api/cart', [
            'product_id' => $product->id,
            'qty' => 2,
        ])->assertStatus(201);

        // Создает заказ
        $response = $this->postJson('/api/orders', [
            'email' => 'guest@example.com',
            'phone' => '+77001112233',
        ]);

        $response->assertStatus(201);
        $this->assertDatabaseHas('orders', ['email' => 'guest@example.com']);
    }

    public function test_user_can_create_order()
    {
        $user = User::firstOrFail();
        $product = Product::firstOrFail();

        // Авторизуемся
        $this->actingAs($user);

        // Кладем в корзину
        $this->postJson('/api/cart', [
            'product_id' => $product->id,
            'qty' => 1,
        ])->assertStatus(201);

        // Создаем заказ
        $response = $this->postJson('/api/orders', [
            'email' => $user->email,
            'phone' => '+77001112233',
        ]);

        $response->assertStatus(201);
        $this->assertDatabaseHas('orders', ['user_id' => $user->id]);
    }
}
