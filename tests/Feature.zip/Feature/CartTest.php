<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Product;
use App\Models\User;
use App\Models\Cart;
use App\Models\CartItem;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CartTest extends TestCase
{
    use RefreshDatabase;

        protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_guest_can_add_item_to_cart()
    {
        $product = Product::firstOrFail();

        $response = $this->postJson('/api/cart', [
            'product_id' => $product->id,
            'qty' => 2,
        ]);

        $response->assertStatus(201)
                 ->assertJsonFragment(['product_id' => $product->id]);
    }

    public function test_user_cart_merges_with_guest_cart_on_login()
    {
        $product = Product::firstOrFail();

        // Гость добавляет товар
        $this->postJson('/api/cart', [
            'product_id' => $product->id,
            'qty' => 2,
        ])->assertStatus(201);

        // Авторизуется
        $user = User::firstOrFail();
        $this->actingAs($user);

        // Добивает еще 1 товар
        $this->postJson('/api/cart', [
            'product_id' => $product->id,
            'qty' => 1,
        ])->assertStatus(201);

        // Проверяем итоговое количество
        $response = $this->getJson('/api/cart');
        $response->assertStatus(200);
        $this->assertEquals(3, $response->json('items.0.qty'));
    }
}
