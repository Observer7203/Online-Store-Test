<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Attribute;
use Illuminate\Validation\Rule;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;

class AttributeController extends Controller
{
    public function index()
    {
        $attributes=Attribute::all();
        return response()->json($attributes);
    }

    public function store(Request $request)
    {
        $data=$request->validate([
            'name'=>'required|string|max:255',
            'code'=>'required|string|max:255|unique:attributes,code',
            'type'=>['required', Rule::in(['int','decimal','bool','string'])],
        ]);

        $attribute=Attribute::create($data);

        response()->json($attribute,201);
    }   

    public function destroy($id)
    {
        $attribute=Attribute::find($id);
        if($attribute)
        {
            $attribute->delete();
            return response()->json(['message'=>'Attribute deleted'],200);
        }
        else
        {
            return response()->json(['message'=>'Attribute not found'],404);
        }
    }
}
