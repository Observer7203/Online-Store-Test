<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Cart;
use Illuminate\Support\Facades\DB;
use App\Http\Resources\OrderResource;

class OrderController extends Controller
{
    // Create Order
    public function store(Request $request)
    {
        $data = $request->validate([
            'email' => 'required|email',
            'phone' => 'required|string|max:20',
        ]);

        // Idempotency key to prevent duplicate orders
        $idempotencyKey = $request->header('Idempotency-Key');
        if ($idempotencyKey && Order::where('idempotency_key', $idempotencyKey)->exists()) {
            return response()->json(['message' => 'Duplicate order'], 200);
        }

        $cart = $this->getCart($request);

        if ($cart->items->isEmpty()) {
            return response()->json(['message' => 'Cart is empty'], 400);
        }

        DB::beginTransaction();
        try {
            $order = Order::create([
                'user_id'        => $request->user()?->id,
                'email'          => $data['email'],
                'phone'          => $data['phone'],
                'total_minor'    => $cart->items->sum(fn($i) => $i->qty * $i->price_snapshot),
                'status'         => 'placed',
                'idempotency_key'=> $idempotencyKey,
            ]);

            foreach ($cart->items as $item) {
                OrderItem::create([
                    'order_id'       => $order->id,
                    'product_id'     => $item->product_id,
                    'name_snapshot'  => $item->product->name,
                    'price_snapshot' => $item->price_snapshot,
                    'qty'            => $item->qty,
                ]);
            }

            $cart->items()->delete();

            DB::commit();

            return (new OrderResource($order->load('items')))
                ->response()
                ->setStatusCode(201);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json(['error' => 'Order creation failed'], 500);
        }
    }

    // List Orders for Authenticated User
    public function index(Request $request)
    {
        if (!$request->user()) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $orders = Order::where('user_id', $request->user()->id)
            ->with('items')
            ->get();

        return OrderResource::collection($orders);
    }

    protected function getCart(Request $request)
    {
        if ($request->user()) {
            return Cart::firstOrCreate(['user_id' => $request->user()->id])->load('items.product');
        }

        $token = $request->cookie('guest_token');
        if (!$token) {
            return new Cart(['items' => collect()]);
        }

        return Cart::where('guest_token', $token)->with('items.product')->firstOrNew();
    }
}
