<?php

namespace App\Http\Controllers;

use App\Http\Resources\CategoryResource;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;

class CategoryController extends Controller
{
    public function tree()
    {
        $categories = Category::with('children.children')->where('depth', 1)->get();
        return CategoryResource::collection($categories);
    }
}
