<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Str;
use App\Http\Resources\CartResource;

class CartController extends Controller
{
    public function index(Request $request)
    {
        $cart = $this->getCart($request)->load('items.product');
        return new CartResource($cart);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'product_id' => 'required|exists:products,id',
            'qty' => 'required|integer|min:1',
        ]);

        $cart = $this->getCart($request);

        $item = $cart->items()->where('product_id', $data['product_id'])->first();

        if ($item) {
            $item->qty += $data['qty'];
            $item->save();
        } else {
            $product = Product::findOrFail($data['product_id']);
            $cart->items()->create(
                [
                    'product_id' => $product->id,
                    'qty' => $data['qty'],
                    'price_snapshot' => $product->price_minor,
                ]
            );
        }

        return (new CartResource($cart->load('items.product')))
            ->response()
            ->setStatusCode(200);
    }

    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'qty' => 'required|integer|min:1',
        ]);

        $cart = $this->getCart($request);
        $item = $cart->items()->where('id', $id)->firstOrFail();
        $item->qty = $data['qty'];
        $item->save();

        return new CartResource($cart->load('items.product'));
    }

    public function destroy(Request $request, $id)
    {
        $cart = $this->getCart($request);
        $item = $cart->items()->where('id', $id)->firstOrFail();
        $item->delete();

        return new CartResource($cart->load('items.product'));
    }

    protected function getCart(Request $request)
    {
        if ($request->user()) {
            return Cart::firstOrCreate(['user_id' => $request->user()->id]);
        }

        $token = $request->cookie('guest_token') ?? Str::uuid()->toString();
        $cart = Cart::firstOrCreate(['guest_token' => $token]);

        // if there's no guest_token cookie, set it
        if (!$request->cookie('guest_token')) {
            cookie()->queue(cookie('guest_token', $token, 60 * 24 * 30)); // 30 дней
        }

        return $cart;
    }
}
