<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Http\Resources\ProductResource;
use App\Models\Attribute;


class ProductController extends Controller
{

    // List of products with optional filtering by category and attributes
    public function index(Request $request)
    {   
        $query = Product::with('category', 'attributes.attribute');
        
        // Filter by category IDs
        if ($request->has('category_ids')) {
            $query->whereIn('category_id', $request->input('category_ids'));
        }

        // Filter by price range
        if ($request->filled('price_min')) {
            $query->where('price_minor', '>=', $request->input('price_min'));
        }
        if ($request->filled('price_max')) {
            $query->where('price_minor', '<=', $request->input('price_max'));
        }

        // Filter by EAV attributes
        if ($request->has('attr')) {
            foreach ($request->input('attr') as $code => $value) {
                // check that the attribute really exists
                $attribute = Attribute::where('code', $code)->first();
                if (!$attribute) {
                    abort(400, "Invalid attribute: $code");
                }
                $query->whereHas('attributes', function($q) use ($code, $value) {
                    if (is_array($value)) {
                        $q->whereHas('attribute', fn($qa) => $qa->where('code', $code))
                          ->whereIn('value_string', $value);
                    } else {
                        $q->whereHas('attribute', fn($qa) => $qa->where('code', $code))
                          ->where('value_string', $value);
                    }
                });
            }
        }

        // Sorting
        if ($request->input('sort') === 'price_asc') {
            $query->orderBy('price_minor', 'asc');
        } elseif ($request->input('sort') === 'price_desc') {
            $query->orderBy('price_minor', 'desc');
        } else {
            $query->latest(); 
        }

        // Pagination
        $products = $query-> paginate(10);
        
        return ProductResource::collection($products);
    }

    public function show($slug)
    {
        $product = Product::with(['category', 'attributes.attribute'])->where('slug', $slug)->firstOrFail();

        return new ProductResource($product);

    }
}
